function test(){

}

test();
