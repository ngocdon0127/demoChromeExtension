

    About *.interface.txt

                                                           Titaniumcore Project
================================================================================
Atsushi Oka [ http://oka.nu/ ]                                      Jan 15,2009

A text file that has the extension ``.interface.txt'' is a description for
JavaScript interface.  Since JavaScript has no type restriction, there is
no particular script file that defines the class interface implicitly. The
specification of the interface is described In the text files that has the
extension ``.interface.txt'' .


================================================================================

// vim:expandtab:
